package com.gitewayservice.gitewayservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GitewayServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
