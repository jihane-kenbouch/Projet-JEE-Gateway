package com.costumer.costumermicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CostumermicroServiceSpringCloudandEurekaRegistryImplementationApplicationTests {

    @Test
    void contextLoads() {
    }

}
