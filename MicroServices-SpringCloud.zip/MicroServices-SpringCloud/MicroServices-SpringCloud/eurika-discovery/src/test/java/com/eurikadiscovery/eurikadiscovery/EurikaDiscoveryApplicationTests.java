package com.eurikadiscovery.eurikadiscovery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurikaDiscoveryApplicationTests {

    @Test
    void contextLoads() {
    }

}
