# MicroServices-SpringCloud
Realization of MicroServices with JEE, Spring Boot, Spring Security, Spring Cloud and Angular

Each folder have a separate microservice from other, but they are linked by one microservice so they can get , post and transfer data so in the finale we have a complete website that use multiple services 
